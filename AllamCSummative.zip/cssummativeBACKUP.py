#Allam Atif
#Summative

#imports and pygame setup

import sys, pygame ,math,os,random
from pygame import *
pygame.init()
 
 
font = pygame.font.SysFont("Times New Roman",30)    
SIZE = (width,height) = (1000,700)
screen = display.set_mode(SIZE)
myClock = time.Clock()

#colours and variables

GREEN = (0,204,0)
BLUE = (0,0,100)
RED = (255,0,0)
WHITE = (255,255,255)

#states defined

intro = 0
game = 1
end = 2
difficultyUp = 3
help = 4
gameEnd = 5
menu = 6
theme = 7 
facts = 8
instructions = 9
diffSet = 10
leaderboard = 11

state = diffSet

#numeric variables defined

difficulty = 1
squareSize = 10
image = 0
xplayer = 0
yplayer = 0
loop = 0

#obsticle setup

obslist = []#add to list    
l = int(len(obslist))

#booleans assigned

running = True
first = True
flip = True
KEY_RIGHT = False
KEY_LEFT = False
KEY_UP = False
KEY_DOWN = False
running1 = True

#images

#load movie

image = []
image1 = []
frame = []

#images loaded

background = pygame.image.load('gamebackground.jpg') 
themeImage = pygame.image.load('theme (2).jpg') 
instructionsImage = pygame.image.load('instructions (2).jpg') 
factsImage = pygame.image.load('facts (2).jpg') 
menuImage = pygame.image.load('menubackground.jpg') 

#images transformed to desired size

background = pygame.transform.scale(background, (1000,700))     
themeImage = pygame.transform.scale(themeImage, (1000,700))   
instructionsImage = pygame.transform.scale(instructionsImage, (1000,700))   
factsImage = pygame.transform.scale(factsImage, (1000,700))   
menuImage = pygame.transform.scale(menuImage, (1000,700))

#image loads
turtle0 = pygame.image.load('turtle.png')     # done once
turtle1 = pygame.image.load('turtle1.png')
obsticle0 = pygame.image.load('garbage-patch-1.jpg') 
obsticle1 = pygame.image.load('garbage-patch-1 - Copy.jpg')

#sounds 
ocean = pygame.mixer.Sound("Beach Waves-SoundBible.com-1024681188.wav")  
theme = pygame.mixer.Sound("theme.wav") 
oogway = pygame.mixer.Sound("there-are-no-accidents.wav") 


#theme music plat    
theme.play()
 
#game loop

while running:   
  
     # variables that update every frame
    playerRect = Rect(xplayer,yplayer,15,15)  
    loop +=  1
    seconds = loop/60     #seconds set
    points = 100-seconds #points system is a percentage, faster the player clears the level, the higher percentage they get
    points = int(points)   
    
    myClock.tick(60)    #frame rate set
    
    if difficulty == 0:   # if the player passes the game, show the win screen
        state = gameEnd
        
    if yplayer >= 690:    #player boundary set
        yplayer = 690
        
    #images change every set number of frames to make it look like waves are going through in the ocean

    if loop%50 == 0:   
        flip = not flip
    if  flip == True:
        turtle = turtle0
        obsticle = obsticle0
    
        obsticle = pygame.transform.scale(obsticle, (squareSize,squareSize ))           
    else:          
        turtle = turtle1
        obsticle = obsticle1
        obsticle = pygame.transform.scale(obsticle, (squareSize,squareSize ))           
          
  
    
    for evnt in event.get():                                       #get events
        if evnt.type == QUIT:                                      #close window, end game
            quit()            
        
            running = False                                         #running loop is ended
               
        if evnt.type  ==  MOUSEBUTTONDOWN  and  state == intro:        #if left click start game
            obslist = []
            loop = 0
            seconds = 0 #resets timer
            for x in range(20,1000, difficulty):                  #draws x and y for obstacles
                y = random.randint(0, 1000)            
                obslist.append(Rect(x,y,squareSize,squareSize))   #adding dimensions to the list            
               
        
            theme.stop()                                          #stop theme music 
          
            state = game
          
        if evnt.type == KEYDOWN:                                  #for the main character to move smoothy and naturally
            
            
            if evnt.key == K_LEFT :
                KEY_LEFT  =  True
            if evnt.key == K_RIGHT:
                KEY_RIGHT = True
                           
            
            if evnt.key == K_UP :
                KEY_UP  =  True
                          
            if evnt.key == K_DOWN :
                KEY_DOWN  =  True
               
                          
                   
       
        if evnt.type == KEYUP:
            if evnt.key == K_LEFT:
                KEY_LEFT  =  False
            if evnt.key == K_RIGHT:
                KEY_RIGHT  =  False
            if evnt.key == K_UP:
                KEY_UP  =  False
            if evnt.key == K_DOWN:
                KEY_DOWN  =  False                                        

    if state == intro:
        
        introImg = pygame.image.load('intro (2).jpg')          #display intoduction image for enriched experience
        introImg = pygame.transform.scale(introImg, (1000,700))   
        screen.blit(introImg, (0, 0)) 
    
        display.flip()
        #close window
        
        
    elif state == game:
        
        screen.blit(background, (0, 0))           #displays background every frame so the image of character from the last frame is removed        
        ocean.play()                              #once game is started run ambient ocean music
        
    
        speed  =  10                                  #sets speed
        z  =  playerRect.collidelist(obslist)         #variable to check collisions
       
        if first == True:                           #check if the game is running for the first time 
            screen.blit(background, (0, 0))       
            for i in range(100,0,-10):            # make the main character large so the auidience can see               
                              
                turtle = pygame.transform.scale(turtle, (i, i)) 
                screen.blit(background, (0, 0))
                screen.blit(turtle, (i,i)) 
                time.wait(250)                    #wait everytime so the audience can see, addictive games are addictive because the gmae makes the players wait
                display.flip()                   
        first = False
        
        turtle = pygame.transform.scale(turtle, (15, 15))  #reverts to original size
                     
        if z != -1:                                        #checks if the character has collided
            ocean.stop()
            state = end               
    
        elif xplayer >= 990:                                 #checks if the player as passed the level 
            ocean.stop()
            state = difficultyUp  
      
        screen.blit(turtle, Rect(xplayer,yplayer,10,10))   #drawing the main player
        

        if KEY_LEFT == True and xplayer >= 10:               #checking if the player is in postion and then letting it move in a natural and smooth fashion
            xplayer -= 2
        if KEY_RIGHT == True  :
            xplayer += 2
        if KEY_UP == True and yplayer>0:
            yplayer -= 2                   
        if KEY_DOWN == True and yplayer <= 690:
            yplayer += 2
        for listNum in obslist:   
            screen.blit(obsticle, Rect(listNum))
            
        display.flip()              
        
      
    elif state == end:  
        
        ocean.stop()
        theme.stop()
        oogway.play() 
       
        for x in range(1,34):                                             
            frame.append(("(%i).jpg"%x))
            image.append(pygame.image.load(frame[x-1])) 
            image1.append(pygame.transform.scale(image[x-1] , (1000,700)))          
 
            screen.blit(image1[x-1], (0, 0)) 
                                    
            time.wait(100)    
            pygame.display.flip()
        
        
        state = menu        
        xplayer = 0
        yplayer = 0
        
        display.update() 
        theme.play()  
        state = diffSet
        
    elif state == difficultyUp:                     #makes the difficulty level noticibly harder so the player is in a state of psychological flow
        font = pygame.font.SysFont("Times New Roman",38)       #new times roman used for a premium and professional look
        screen.blit(menuImage, (0, 0))   
        xplayer  =  0   
        if difficulty  == 1:
            difflevel = 'Expert'
        elif difficulty  == 2:
            difflevel  =  'Intermediate' 
        elif difficulty  == 3:
            difflevel = 'Beginner'        
        display.set_caption('Show Text') 
        draw.rect(screen, BLUE, (250,300, 500, 300)) 
        text  = font.render('DIFFICULTY LEVEL IS:', True, RED) 
        text2 = font.render(str( difflevel ), True, RED)
        text3 = font.render(str(points), True, RED)
        text4 = font.render('Your % is', True, RED)             #point system mention in line 92
        textRect = text.get_rect()
        textRect2 = text2.get_rect()
        textRect3 = text3.get_rect()
        textRect4 = text4.get_rect()
        textRect.center  =  (1000 // 2, 700 // 2)                #text cneter for aesthetics
        textRect2.center = (500, 450)                          #different heights for quick reading
        textRect3.center = (500, 550) 
        textRect4.center = (500, 500) 
        points = 0
         
        
        screen.blit(text, textRect) 
        screen.blit(text2, textRect2)
        screen.blit(text3, textRect3)
        screen.blit(text4, textRect4)
        display.update()
        time.wait(1000)  
        theme.play()
        state = diffSet                                            #the intro state gives the audinece some time to get mentally prepared
        
        display.flip()   

    elif state ==  menu:
        screen.blit(menuImage, (0, 0))
        font = pygame.font.SysFont("Times New Roman",52)       #new times roman used for a premium and professional look
        draw.rect(screen, WHITE, (0,235, 1000, 60)) 
        string0 = "Click and Hold!"
        string1 = "Play Game"
        string2 = "Instructions"
        string3 = "Fun Facts"
        string4 = 'Inspiration'
        text0 = font.render(string0, 100, BLUE)
        text1 = font.render(string1, 100, BLUE)
        text2 = font.render(string2,  100, BLUE)
        text3 = font.render(string3, 100, BLUE)
        text4 = font.render(string4, 100, BLUE)
   

         #making the boxes
        for i in range(0,1000,255):
            pygame.draw.rect(screen, GREEN, (i,235,245,60))
        pygame.draw.rect(screen, GREEN, (0,500,320,60))
        #text generation
        screen.blit(text0, pygame.Rect(0, 500, 145, 105))
        screen.blit(text1, pygame.Rect(0, 235, 145, 105))
        screen.blit(text2, pygame.Rect(255, 235, 145, 105))
        screen.blit(text3, pygame.Rect(510, 235, 245, 105))
        screen.blit(text4, pygame.Rect(766, 235, 245, 105))      
        
        pygame.display.flip()
        
        x1, y1 = pygame.mouse.get_pos()#gets the position
        for evnt in pygame.event.get():#gets the events
             
           
                
                if 0 <= x1 <= 255:
                    if  evnt.type == MOUSEBUTTONDOWN:
                        state = intro 
                        
                elif 510 >= x1 >= 255:
                    if  evnt.type == MOUSEBUTTONDOWN:
                        state = instructions
                        
                elif 765 >= x1 >= 510:
                    if  evnt.type == MOUSEBUTTONDOWN:
                        state = facts
                
                elif 1000 >= x1 >= 765:  
                    if evnt.type == MOUSEBUTTONDOWN:
                        state = theme
                
                elif evnt.type == pygame.QUIT:
                    difficulty = 0

                    quit()
                    running = False
                
    
    elif state == instructions:                        #displays the instructions in an exillariating way
        screen.blit(background, (0, 0))    
        screen.blit(instructionsImage, (0,0))
        display.flip()
        if evnt.type  == pygame.MOUSEBUTTONUP: 
            state = menu        
    elif state == facts :                              #displays facts about the state of the issue to raise awareness
        screen.blit(background, (0, 0))   
        screen.blit(factsImage, (0, 0)) 
        display.flip()
        if evnt.type == pygame.MOUSEBUTTONUP:
            state = menu                  
    elif state == theme:                               #displays information about the background of the game and directs the users to a website which supports the cause
        screen.blit(background, (0, 0))   
         
        screen.blit(themeImage, (0, 0))  
   
       
        display.flip()
        if  evnt.type == pygame.MOUSEBUTTONUP:
            state = menu
    elif state == diffSet:
        ocean.stop()
        screen.blit(menuImage, (0, 0))
        font = pygame.font.SysFont("Times New Roman",48)       #new times roman used for a premium and professional look
        draw.rect(screen, WHITE, (0,235, 1000, 60))         
        
        string1 = "Beginner"
        string2 = "Intermediate"
        string3 = "Expert"
        string4 = 'Quit'
        text1 = font.render(string1, 100, BLUE)
        text2 = font.render(string2,  100, BLUE)
        text3 = font.render(string3, 100, BLUE)
        text4 = font.render(string4, 100, BLUE)
    
    
         #making the boxes
        for i in range(0,1000,255):
            pygame.draw.rect(screen, GREEN, (i,235,245,60))
        
        #text generation
        screen.blit(text1, pygame.Rect(0, 235, 145, 105))
        screen.blit(text2, pygame.Rect(255, 235, 145, 105))
        screen.blit(text3, pygame.Rect(510, 235, 245, 105))
        screen.blit(text4, pygame.Rect(766, 235, 245, 105))      
        
        pygame.display.flip()
        
        x1, y1 = pygame.mouse.get_pos()#gets the position
        for evnt in pygame.event.get():#gets the events
             
            if 315 >= y1 >= 235 and evnt.type == pygame.MOUSEBUTTONDOWN:
                
                if 0 <= x1 <= 255:
                    difficulty = 3
                    state = menu
                    
                elif 510 >= x1 >= 255:
                    difficulty = 2
                    state = menu
                    
                elif 765 >= x1 >= 510:
                    difficulty = 1
                    state = menu
                elif 1000 >= x1 >= 765:        
                    pygame.quit()                    
                          
            elif evnt.type == pygame.QUIT:
                difficulty = 0
                quit()
                running = False    
    print(seconds)